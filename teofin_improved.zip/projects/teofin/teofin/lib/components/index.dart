import 'package:flutter/material.dart';

class ComponentsIndex {
  // تصدير جميع المكونات من ملف واحد لسهولة الاستيراد
  static const String version = '1.0.0';
}
